package edu.utsa.cs3443.scc_passwordjuggernaut.model;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;

public class  PasswordHandler {

    private String password;

    public void generatePassword(boolean includeSpecialChar, boolean includeNumbers, int length){
        //code to generate random password using variables above.
        String numbers = "0123456789";
        String specialChars = "!@#$%^&*()-_=+[]{}|;:'.<>?/\\";
        String upperCase = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        String lowerCase = "abcdefghijklmnopqrstuvwxyz";

        StringBuilder charPool = new StringBuilder();
        charPool.append(upperCase);
        charPool.append(lowerCase);

        if (includeNumbers){
            charPool.append(numbers);
        }
        if (includeSpecialChar){
            charPool.append(specialChars);
        }

        Random random = new Random();
        StringBuilder result = new StringBuilder();

        for (int i = 0 ; i < length; i++){
            result.append(charPool.charAt(random.nextInt(charPool.length())));
        }

        this.password = result.toString();
    }

    public String getPassword() {
        return this.password;
    }

    public String[] deleteArray(String[] list, int index){
        //this will delete the password and return the new array.
        ArrayList<String> arrayList = new ArrayList<>(Arrays.asList(list));
        arrayList.remove(index - 1);
        return arrayList.toArray(new String[0]);
    }

}
