package edu.utsa.cs3443.scc_passwordjuggernaut;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import edu.utsa.cs3443.scc_passwordjuggernaut.model.FileHandler;
import edu.utsa.cs3443.scc_passwordjuggernaut.model.PasswordHandler;

public class GenerateActivity extends AppCompatActivity {

    private String username;
    private boolean includeNumbers;
    private boolean includeSpecialChars;
    private int length;
    private EditText lengthEditText;
    private TextView passwordTextView;
    private String result;
    private FileHandler fileHandler;
    private PasswordHandler passwordHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_generate);

        username = getIntent().getStringExtra("username");
        includeSpecialChars = true;
        includeNumbers = true;
        length = 0;

        lengthEditText = findViewById(R.id.edittext_length);
        Button trueChar = findViewById(R.id.button_trueChar);
        Button falseChar = findViewById(R.id.button_falseChar);
        Button trueNum = findViewById(R.id.button_trueNum);
        Button falseNum = findViewById(R.id.button_falseNum);
        Button generate = findViewById(R.id.button_generate);
        Button save = findViewById(R.id.button_save);
        Button back = findViewById(R.id.button_back);
        passwordTextView = findViewById(R.id.textview_results);

        fileHandler = new FileHandler();
        passwordHandler = new PasswordHandler();

        trueChar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                includeSpecialChars = true;
                Toast.makeText(GenerateActivity.this, "Including Special Characters!", Toast.LENGTH_SHORT).show();
            }
        });

        falseChar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                includeSpecialChars = false;
                Toast.makeText(GenerateActivity.this, "Not Including Special Characters!", Toast.LENGTH_SHORT).show();
            }
        });

        trueNum.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                includeNumbers = true;
                Toast.makeText(GenerateActivity.this, "Including Numbers!", Toast.LENGTH_SHORT).show();
            }
        });

        falseNum.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                includeNumbers = false;
                Toast.makeText(GenerateActivity.this, "Not Including Numbers!", Toast.LENGTH_SHORT).show();
            }
        });

        generate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try{
                    length = Integer.parseInt(lengthEditText.getText().toString());
                    if (length >= 8 && length <= 20){
                        passwordHandler.generatePassword(includeSpecialChars, includeNumbers, length);
                        result = passwordHandler.getPassword();
                        passwordTextView.setText(result);
                    }
                    else{
                        Toast.makeText(GenerateActivity.this, "Invalid Length", Toast.LENGTH_SHORT).show();
                    }
                }
                catch(NumberFormatException e){
                    Toast.makeText(GenerateActivity.this, "Invalid Length Input", Toast.LENGTH_SHORT).show();
                }
            }
        });

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (fileHandler.repeatedPassword(username, result, GenerateActivity.this)){
                    Toast.makeText(GenerateActivity.this, "Already Saved Password", Toast.LENGTH_SHORT).show();
                }
                else if (result == null || result.isEmpty()){
                    Toast.makeText(GenerateActivity.this, "Missing Generated Password", Toast.LENGTH_SHORT).show();
                }
                else{
                    fileHandler.savePassword(username, result, GenerateActivity.this);
                    Toast.makeText(GenerateActivity.this, "Password Saved!", Toast.LENGTH_SHORT).show();
                }
            }
        });

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(GenerateActivity.this, HomeActivity.class);
                intent.putExtra("username", username);
                startActivity(intent);
                finish();
            }
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}