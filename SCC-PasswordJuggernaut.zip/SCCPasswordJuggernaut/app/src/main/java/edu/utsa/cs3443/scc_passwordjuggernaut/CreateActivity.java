package edu.utsa.cs3443.scc_passwordjuggernaut;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import edu.utsa.cs3443.scc_passwordjuggernaut.model.FileHandler;

public class CreateActivity extends AppCompatActivity {

    private EditText usernameEditText;
    private EditText passwordEditText;
    private FileHandler fileHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_create);

        usernameEditText = findViewById(R.id.edittext_username);
        passwordEditText = findViewById(R.id.edittext_password);
        Button doneButton = findViewById(R.id.button_done);
        Button backButton = findViewById(R.id.button_back);

        fileHandler = new FileHandler();

        doneButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                String username = usernameEditText.getText().toString();
                String password = passwordEditText.getText().toString();

                if (fileHandler.usernameTaken(username, CreateActivity.this)) {
                    Toast.makeText(CreateActivity.this, "Username Taken", Toast.LENGTH_SHORT).show();
                }
                else if (username.isEmpty() || password.isEmpty()){
                    Toast.makeText(CreateActivity.this, "Missing Inputs", Toast.LENGTH_SHORT).show();
                }
                else if (fileHandler.isFull(CreateActivity.this)){
                    Toast.makeText(CreateActivity.this, "Max 20 Users", Toast.LENGTH_SHORT).show();
                }
                else{
                    fileHandler.createUser(username, password, CreateActivity.this);
                    Toast.makeText(CreateActivity.this, "User Created", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(CreateActivity.this, MainActivity.class);
                    startActivity(intent);
                    finish();
                }
            }
        });

        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                Intent intent = new Intent(CreateActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
            }
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}