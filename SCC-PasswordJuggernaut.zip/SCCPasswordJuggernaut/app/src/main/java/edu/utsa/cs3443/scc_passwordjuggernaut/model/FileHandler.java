package edu.utsa.cs3443.scc_passwordjuggernaut.model;

import android.content.Context;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class FileHandler {

    private String userfile = "users.csv";
    private String passwordfile = "passwords.csv";

    public boolean authenticateUser(String username, String password, Context context){
        //this will confirm that the username and password is correct when user is logging in.\
        try (FileInputStream fis = context.openFileInput(userfile);
             InputStreamReader isr = new InputStreamReader(fis);
             BufferedReader reader = new BufferedReader(isr)){
            String line;
            while ((line = reader.readLine()) != null){
                String[] tokens = line.split(",");
                if (tokens[0].equals(username) && tokens[1].equals(password)){
                    return true;
                }
            }
        }
        catch (IOException e){
            e.printStackTrace();
        }
        return false;
    }

    public boolean usernameTaken(String username, Context context){
        //this will check users.csv and check if the username repeats itself.
        try (FileInputStream fis = context.openFileInput(userfile);
             InputStreamReader isr = new InputStreamReader(fis);
             BufferedReader reader = new BufferedReader(isr)){
            String line;
            while ((line = reader.readLine()) != null){
                String[] tokens = line.split(",");
                if (tokens[0].equals(username)){
                    return true;
                }
            }
        }
        catch (IOException e){
            e.printStackTrace();
        }
        return false;
    }

    public boolean isFull(Context context){
        //this checks if user is at max capacity
        final int MAX_USERS = 20;
        int count = 0;

        try (FileInputStream fis = context.openFileInput(userfile);
             InputStreamReader isr = new InputStreamReader(fis);
             BufferedReader reader = new BufferedReader(isr)){
            String line;
            while ((line = reader.readLine()) != null){
                count++;
            }
            if (count >= MAX_USERS){
                return true;
            }
        }
        catch (IOException e){
            e.printStackTrace();
        }
        return false;
    }

    public void createUser(String username, String password, Context context){
        //this will write the username and password into users.csv.
        try{
            FileOutputStream file = context.openFileOutput(userfile, Context.MODE_APPEND);
            OutputStreamWriter output = new OutputStreamWriter(file);
            output.write(username + "," + password + "\n");
            output.close();
        }
        catch (IOException e){
            e.getStackTrace();
        }
    }

    public void savePassword(String username, String password, Context context){
        //this will write saved password with username into passwords.csv
        try{
            FileOutputStream file = context.openFileOutput(passwordfile, Context.MODE_APPEND);
            OutputStreamWriter output = new OutputStreamWriter(file);
            output.write(username + "," + password + "\n");
            output.close();
        }
        catch (IOException e){
            e.getStackTrace();
        }
    }

    public boolean repeatedPassword(String username, String password, Context context){
        //this will check if the password is repeated just incase (very unlikely).
        try (FileInputStream fis = context.openFileInput(passwordfile);
             InputStreamReader isr = new InputStreamReader(fis);
             BufferedReader reader = new BufferedReader(isr)){
            String line;
            while ((line = reader.readLine()) != null){
                String[] tokens = line.split(",");
                if (tokens[0].equals(username) && tokens[1].equals(password)){
                    return true;
                }
            }
        }
        catch (IOException e){
            e.printStackTrace();
        }
        return false;
    }

    public String[] storeList(String username, Context context){
        //this will store the users list
        ArrayList<String> passwordList = new ArrayList<>();
        try (FileInputStream fis = context.openFileInput(passwordfile);
             InputStreamReader isr = new InputStreamReader(fis);
             BufferedReader reader = new BufferedReader(isr)){
            String line;
            while ((line = reader.readLine()) != null){
                String[] tokens = line.split(",");
                if (tokens[0].equals(username)){
                    passwordList.add(tokens[1]);
                }
            }
        }
        catch (IOException e){
            e.printStackTrace();
        }
        return passwordList.toArray(new String[0]);
    }

    public void updatePasswords(String username, String[] list, Context context){
        List<String> lines = new ArrayList<>();

        try (FileInputStream fis = context.openFileInput(passwordfile);
             InputStreamReader isr = new InputStreamReader(fis);
             BufferedReader reader = new BufferedReader(isr)){
            String line;
            while ((line = reader.readLine()) != null){
                String[] tokens = line.split(",");
                if (tokens[0].equals(username)){
                    if (Arrays.asList(list).contains(tokens[1])){
                        lines.add(line);
                    }
                }
                else{
                    lines.add(line);
                }
            }
        }
        catch (IOException e){
            e.printStackTrace();
        }

        try (FileOutputStream fos = context.openFileOutput(passwordfile, Context.MODE_PRIVATE);
             OutputStreamWriter output = new OutputStreamWriter(fos)) {
            for (String line : lines) {
                output.write(line + "\n");
            }
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

}
